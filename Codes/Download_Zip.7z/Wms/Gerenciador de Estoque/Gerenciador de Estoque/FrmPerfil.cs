﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gerenciador_de_Estoque
{
    public partial class FrmPerfil : Form
    {
        public FrmPerfil()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmPerfil_Load(object sender, EventArgs e)
        {

        }

        private void TxtCriarUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtCriarSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCriarUsuario_Click(object sender, EventArgs e)
        {
            string novoUsuario = TxtCriarUsuario.Text;
            string novaSenha = TxtCriarSenha.Text;

            if (string.IsNullOrWhiteSpace(novoUsuario) || string.IsNullOrWhiteSpace(novaSenha))
            {
                MessageBox.Show("Usuário e senha não podem estar vazios.");
                return;
            }

            if (AdicionarUsuario(novoUsuario, novaSenha))
            {
                MessageBox.Show("Usuário criado com sucesso!");
                TxtCriarUsuario.Clear();
                TxtCriarSenha.Clear();
            }
            else
            {
                MessageBox.Show("Erro ao criar usuário. Verifique se o arquivo existe.");
            }


        }
        private bool AdicionarUsuario(string usuario, string senha)
        {
            // Caminho do arquivo onde estão armazenados os usuários e senhas
            string caminhoArquivo = "C:\\Users\\Pichau\\Desktop\\Exercicios coding\\Wms\\usuarios.txt";

            try
            {

                // Adiciona o novo usuário e senha ao final do arquivo
                using (StreamWriter sw = File.AppendText(caminhoArquivo))
                {
                    sw.WriteLine($"{usuario};{senha}");
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}");
                return false;
            }
        }
    }
}
